# funk/db.py
import sqlite3
from typing import Optional, List, Dict, Any

# Путь к файлу базы данных
# Лучше положить users.db в корень проекта (рядом с main.py)
DB_FILE = "users.db"  # если нужно — можно сделать "../users.db" или абсолютный путь


def get_connection() -> sqlite3.Connection:
    """Создаёт и возвращает новое соединение с базой"""
    return sqlite3.connect(DB_FILE)


def init_db() -> None:
    """
    Создаёт таблицу users, если её ещё не существует.
    Вызывать один раз при запуске бота.
    """
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id                  INTEGER PRIMARY KEY,
                is_bot              BOOLEAN         NOT NULL,
                first_name          TEXT,
                username            TEXT,
                last_name           TEXT,
                language_code       TEXT,
                is_premium          BOOLEAN         DEFAULT 0,
                created_at          DATETIME        DEFAULT CURRENT_TIMESTAMP,
                updated_at          DATETIME        DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()


def save_or_update_user(user) -> None:
    """
    Добавляет нового пользователя или обновляет данные существующего.
    user — это объект message.from_user из telebot (types.User)
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO users (
                id, is_bot, first_name, username, last_name,
                language_code, is_premium
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                is_bot          = excluded.is_bot,
                first_name      = excluded.first_name,
                username        = excluded.username,
                last_name       = excluded.last_name,
                language_code   = excluded.language_code,
                is_premium      = excluded.is_premium,
                updated_at      = CURRENT_TIMESTAMP
        """, (
            user.id,
            user.is_bot,
            user.first_name,
            user.username,
            user.last_name,
            user.language_code,
            user.is_premium
        ))
        conn.commit()


def get_user_by_id(user_id: int) -> Optional[Dict[str, Any]]:
    """
    Возвращает данные пользователя по его Telegram ID.
    Если пользователя нет → возвращает None.
    """
    with get_connection() as conn:
        conn.row_factory = sqlite3.Row  # чтобы получить результат как словарь
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM users WHERE id = ?
        """, (user_id,))
        row = cursor.fetchone()
        return dict(row) if row else None


def get_all_users() -> List[Dict[str, Any]]:
    """
    Возвращает список всех пользователей в базе (словарь для каждого).
    Полезно для админ-команд, статистики и т.д.
    """
    with get_connection() as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM users
            ORDER BY created_at DESC
        """)
        return [dict(row) for row in cursor.fetchall()]


def count_users() -> int:
    """Просто количество пользователей в базе"""
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        return cursor.fetchone()[0]
