import openai

def ai(ai_token, message):
    try:
        client = openai.OpenAI(
            api_key=ai_token,
            base_url="https://openrouter.ai/api/v1"
        )
        response = client.chat.completions.create(
            model="openrouter/aurora-alpha",
            messages=[
                {"role": "system", "content": "Отвечай в красивом Telegram Markdown: **жирный**, *курсив*, списки, ```код```, > цитаты."},
                {"role": "user", "content": message.text}
            ],
        )
        text = response.choices[0].message.content.strip()  # сразу убираем лишние пробелы по краям

        if not text:
            return ["Я не понял, что ответить 😕"]

        
        MAX_PART = 3900
        parts = []
        while text:
            if len(text) <= MAX_PART:
                parts.append(text)
                break
            # ищем последний перенос строки или пробел перед лимитом
            split_pos = text.rfind('\n', 0, MAX_PART)
            if split_pos == -1:
                split_pos = text.rfind(' ', 0, MAX_PART)
            if split_pos == -1:
                split_pos = MAX_PART
            else:
                split_pos += 1  # включаем перенос/пробел в текущий кусок

            part = text[:split_pos].rstrip()
            if part:                    # не добавляем пустые куски
                parts.append(part)
            text = text[split_pos:].lstrip()

        if not parts:
            return ["Ответ получился пустым, попробуй переспросить"]

        return parts

    except Exception as e:
        print(e)
        return ["Неизвестная ошибка на стороне сервера"]
        

