import edge_tts
import asyncio
import os

async def text_to_speech_edge(
    text: str,
    character: str = "ru-RU-SvetlanaNeural",
    output_file: str = "output.mp3"
):
    """
    Преобразует текст в речь с использованием Edge TTS и сохраняет в аудиофайл.
    """
    try:
        communicate = edge_tts.Communicate(text, character)
        await communicate.save(output_file)
        print(f"✅ Сохранено: {output_file}")
        return True # Возвращаем True в случае успеха
    except Exception as e:
        print(f"❌ Ошибка при сохранении аудио: {e}")
        return False # Возвращаем False в случае ошибки

def tts_run(message, id):
    try:
        char=message.split(' ')
        if char[1]=='man':
            del char[0], char[0]
            text=' '.join(char)
            asyncio.run(text_to_speech_edge(text, "ru-RU-SvetlanaNeural", id))
        elif char[1]=='girl':
            del char[0], char[0]
            text=' '.join(char)
            asyncio.run(text_to_speech_edge(text, "ru-RU-DmitryNeural", id))
        else:
            return "false" 
    except Exception as e:
        print(f"❌ Ошибка при обработке команды TTS: {e}")
        return "false"







