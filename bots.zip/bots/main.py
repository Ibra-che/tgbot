from dotenv import load_dotenv 
import os
from datetime import datetime as dt
import telebot
from funk.send_ai import ai
from funk.bd import init_db, save_or_update_user, get_user_by_id, get_all_users, count_users
from funk.tts import tts_run

load_dotenv()

token=os.getenv('TOKEN')
admin=os.getenv('ADMIN')
ai_token=os.getenv('API_OPN')

users_who_wrote = set()
forwarded_messages = {}
bans=[]

bot=telebot.TeleBot(token)

def save_all_messages(messages):
    with open("logs/messages_log.txt", "a", encoding="utf-8") as f:
        f.write(f"time:{dt.now()}| id: {messages.from_user.id}| text: {messages.text}\n")

def write_file(data=None):
    filename="resurs.txt"
    if data is None:
        return
    else:
        data = data.split(' ')
        with open(filename, 'a') as f:
            f.write(f'{data[0]} {data[1]}\n')


@bot.message_handler(commands=['start'])
def cmd_start(message):
    save_all_messages(message)
    markup = telebot.types.InlineKeyboardMarkup(row_width=2)

    btn1 = telebot.types.InlineKeyboardButton("my channel", url='https://t.me/pyibra')
    if message.from_user.is_premium:
        btn2 = telebot.types.InlineKeyboardButton("bost", url='https://t.me/boost/pyibra')
        markup.add(btn1, btn2) 
    else:
        markup.add(btn1)

    save_or_update_user(message.from_user)
    bot.reply_to(message, f'''Ассалам Алейкум, {message.from_user.first_name or 'человек'}
    это бот для оборатной связи, остольные плюшки добавлены по приколу. Что бы узнать все команды
    нажмите на кнопку ниже или введите команду /help''', reply_markup=markup)    

@bot.message_handler(commands=['ban'])
def cmd_ban(message):
    save_all_messages(message)
    if message.from_user.id==int(admin):
        try:
            user_id_to_ban = int(message.text.split()[1])
            bans.append(user_id_to_ban)
            bot.reply_to(message, f"Пользователь с ID {user_id_to_ban} был забанен.")
        except (IndexError, ValueError):
            bot.reply_to(message, "Пожалуйста, укажите ID пользователя для бана. Пример: /ban 123456789")
    else:
        bot.reply_to(message, "У вас нет прав для использования этой команды.")

@bot.message_handler(commands=['newsite'])
def cmd_new_site(message):
    save_all_messages(message)
    if message.from_user.id==int(admin):
        try:
            data = message.text.split(maxsplit=2)[1:]
            if len(data) < 2:
                bot.reply_to(message, "Пожалуйста, укажите название и ссылку. Пример: /newsite Google https://www.google.com")
                return
            write_file(' '.join(data))
            bot.reply_to(message, f"Сайт '{data[0]}' с ссылкой '{data[1]}' был добавлен.")
        except Exception as e:
            bot.reply_to(message, f"Произошла ошибка: {str(e)}")
    else:
        bot.reply_to(message, "У вас нет прав для использования этой команды.")

@bot.message_handler(commands=['site'])
def cmd_site(message):
    try:
        # Читаем файл (замени на свою функцию, если есть)
        with open('resurs.txt', 'r', encoding='utf-8') as f:
            lines = f.read().splitlines()

        duc = {}
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):  # пропускаем пустые и комментарии
                continue
            parts = line.split(maxsplit=1)  # делим на 2 части: название и ссылка
            if len(parts) == 2:
                key, url = parts
                duc[key.strip()] = url.strip()

        if not duc:
            bot.reply_to(message, "Список сайтов пуст или файл не читается 😔")
            return

        # Создаём одну клавиатуру со всеми кнопками
        markup = telebot.types.InlineKeyboardMarkup(row_width=1)  # 1 кнопка в ряд (можно 2)

        for name, link in duc.items():
            btn = telebot.types.InlineKeyboardButton(
                text=name,
                url=link
            )
            markup.add(btn)

        # Отправляем одно сообщение со всеми кнопками
        bot.reply_to(
            message,
            "Вот список полезных ссылок и ресурсов:",
            reply_markup=markup
        )

    except FileNotFoundError:
        bot.reply_to(message, "Файл resurs.txt не найден! 😢")
    except Exception as e:
        bot.reply_to(message, f"Произошла ошибка: {str(e)}")

@bot.message_handler(commands=['allbans'])
def cmd_all_bans(message):
    save_all_messages(message)
    if message.from_user.id==int(admin):
        if bans:
            banned_users = "\n".join(str(user_id) for user_id in bans)
            bot.reply_to(message, f"Забаненные пользователи:\n{banned_users}")
        else:
            bot.reply_to(message, "Пока нет забаненных пользователей.")
    else:
        bot.reply_to(message, "У вас нет прав для использования этой команды.")

@bot.message_handler(commands=['logs'])
def cmd_logs(message):
    if message.from_user.id==int(admin):
        try:
            bot.send_document(message.chat.id, open("logs/messages_log.txt", "rb"))
        except Exception as e:
            bot.reply_to(message, f"Ошибка при отправке логов: {e}")
    else:
        bot.reply_to(message, "У вас нет прав для использования этой команды.")

@bot.message_handler(commands=['ideas'])
def cmd_ideas(message):
    save_all_messages(message)
    if message.from_user.id==int(admin):
        try:
            bot.send_document(message.chat.id, open("idea.txt", "rb"))
        except Exception as e:
            bot.reply_to(message, f"Ошибка при отправке идей: {e}")
    else:
        bot.reply_to(message, "У вас нет прав для использования этой команды.")

@bot.message_handler(commands=['unban'])
def cmd_unban(message):
    save_all_messages(message)
    if message.from_user.id==int(admin):
        try:
            user_id_to_unban = int(message.text.split()[1])
            if user_id_to_unban in bans:
                bans.remove(user_id_to_unban)
                bot.reply_to(message, f"Пользователь с ID {user_id_to_unban} был разбанен.")
            else:
                bot.reply_to(message, f"Пользователь с ID {user_id_to_unban} не найден в бан-листе.")
        except (IndexError, ValueError):
            bot.reply_to(message, "Пожалуйста, укажите ID пользователя для разбана. Пример: /unban 123456789")
    else:
        bot.reply_to(message, "У вас нет прав для использования этой команды.") 

@bot.message_handler(commands=['suggest']) 
def suggest(message):
    text = message.text.split(' ')
    del text[0]
    text = ' '.join(text)
    with open("idea.txt", "a", encoding="utf-8") as f:
        f.write(f"time:{dt.now()}| id: {message.from_user.id}| text: {text}\n")
    bot.reply_to(message, "Ваш совет сохранён.")

@bot.message_handler(commands=['tts'])
def tts(message):
    save_all_messages(message)
    try:
        response=tts_run(message.text, f"{message.from_user.id}.mp3")
        if response=="false":
            bot.reply_to(message, "Голос не найден. Доступные голоса: man, girl.")
        else:
            with open(f"{message.from_user.id}.mp3", 'rb') as audio:
                bot.send_audio(message.chat.id, audio)
            os.remove(f"{message.from_user.id}.mp3")
    except Exception as e:
        bot.reply_to(message, f"Дождитесь обработки предыдущей команды.")

@bot.message_handler(commands=['help'])
def cmd_help(message):
    save_all_messages(message)
    if message.from_user.id==int(admin):
        help_text = (
            "Доступные команды для администратора:\n"
            "/start - Зарегистрироваться в базе данных\n"
            "/help - Показать это сообщение\n"
            "/logs - Получить логи (только админ)\n"
            "/ideas - Получить идеи (только админ)\n"
            "/allbans - Показать всех забаненных пользователей (только админ)\n"
            "/ai - Получить ответ от ИИ (пример: /ai Привет, как дела?)\n"
            "/tts - Преобразовать текст в речь (пример: /tts {man или girl} Привет, как дела?)\n"            
            "/profile или /me - Показать информацию о себе\n"
            "/allusers - Показать всех пользователей (только первые 15)\n"
            "/initbd - Инициализировать базу данных (только админ)\n"
            "/ban - Забанить пользователя (только админ)\n"
            "/unban - Разбанить пользователя (только админ)\n"
            "/newsite - Добавить новый сайт (только админ)\n"
            '/site - Показать список сайтов\n'
            "/suggest - Отправить совет или идею для улучшения бота (пример: /suggest Добавьте функцию X)"
            "\n"
            "Чтобы ответить пользователю, сделайте реплай на его сообщение и напишите ответ."
        )
        bot.reply_to(message, help_text)
    else:
        help_text = (
            "Доступные команды:\n"
            "/start - Зарегистрироваться в базе данных\n"
            "/help - Показать это сообщение\n"
            "/ai - Получить ответ от ИИ (пример: /ai Привет, как дела?)\n"
            "/tts - Преобразовать текст в речь (пример: /tts {man или girl} Привет, как дела?)\n"
            "/profile или /me - Показать информацию о себе\n"
            "/suggest - Отправить совет или идею для улучшения бота (пример: /suggest Добавьте функцию X)"
            "\n"
            "Чтобы связаться с поддержкой, просто отправьте сообщение, и оно будет передано администратору."
        )
        bot.reply_to(message, help_text)

@bot.message_handler(commands=['ai'])  
def chat_ai(message):
    save_all_messages(message) 
    try:
        parts = ai(ai_token, message)
        
        for idx, part in enumerate(parts, 1):
            if not part.strip():          # защита от пустых кусков
                continue
                
            text_to_send = part
            if len(parts) > 1:
                text_to_send = f"Часть {idx}/{len(parts)}\n\n" + part
            
            bot.reply_to(message, text_to_send)
            
    except Exception as e:
        print(e)
        bot.reply_to(message, "Что-то пошло не так 😔")

@bot.message_handler(commands=['initbd'])
def initbd(message):
    save_all_messages(message)
    if message.from_user.id==int(admin):
        init_db()

@bot.message_handler(commands=['profile', 'me'])
def cmd_profile(message):
    save_all_messages(message)
    user_data = get_user_by_id(message.from_user.id)
    if not user_data:
        bot.reply_to(message, "Тебя нет в базе. Напиши /start")
        return

    text = (
        f"🆔 ID: {user_data['id']}\n"
        f"👤 Имя: {user_data['first_name'] or '—'}\n"
        f"🔹 Username: @{user_data['username'] or 'нет'}\n"
        f"👥 Фамилия: {user_data['last_name'] or '—'}\n"
        f"🌐 Язык: {user_data['language_code'] or '?'}\n"
        f"⭐ Премиум: {'да' if user_data['is_premium'] else 'нет'}\n"
        f"📅 Зарегистрирован: {user_data['created_at']}\n"
        f"🔄 Последнее обновление: {user_data['updated_at']}"
        )
    bot.reply_to(message, text)
    
@bot.message_handler(commands=['allusers'])  
def cmd_all_users(message):
    save_all_messages(message)
    if message.from_user.id==int(admin):

        users = get_all_users()
        if not users:
            bot.reply_to(message, "В базе пока никого нет.")
            return

        lines = [f"Всего пользователей: {len(users)}\n"]
        for u in users[:15]:  # ограничим вывод, чтобы не заспамить
            username = f"@{u['username']}" if u['username'] else "без юзернейма"
            lines.append(
                f"• {u['first_name'] or '?'}  {username}  (id: {u['id']})")

        if len(users) > 15:
            lines.append(f"...и ещё {len(users)-15} пользователей")

        bot.reply_to(message, "\n".join(lines))
    else:
        pass #НЕ забыть
        
@bot.message_handler(content_types=['text', 'photo', 'video', 'animation', 'voice', 'sticker', 'document'])
def main_handler(message):
    save_all_messages(message)
    user_id = message.from_user.id

    if user_id == int(admin):
        # ──────────────── Логика ответа администратора ────────────────
        if not message.reply_to_message:
            bot.reply_to(message, "Чтобы ответить — сделай реплай на сообщение пользователя (или на подпись под ним).")
            return

        # Ищем связь по цепочке реплаев (до 5 шагов вверх)
        current = message.reply_to_message
        target_user_id = None
        original_msg_id = None

        for _ in range(6):
            if current.message_id in forwarded_messages:
                target_user_id, original_msg_id = forwarded_messages[current.message_id]
                break
            if current.reply_to_message:
                current = current.reply_to_message
            else:
                break

        if not target_user_id:
            bot.reply_to(message, "Не нашёл пользователя по этому реплаю.\nПопробуй ответить прямо на сообщение от пользователя.")
            return

        # Отправляем ответ пользователю
        try:
            prefix = "Ответ от поддержки:\n\n"

            if message.text:
                bot.send_message(
                    target_user_id,
                    prefix + message.text,
                    reply_to_message_id=original_msg_id
                )
            elif message.photo:
                bot.send_photo(
                    target_user_id,
                    message.photo[-1].file_id,
                    caption=prefix + (message.caption or ""),
                    reply_to_message_id=original_msg_id
                )
            elif message.video:
                bot.send_video(
                    target_user_id,
                    message.video.file_id,
                    caption=prefix + (message.caption or ""),
                    reply_to_message_id=original_msg_id
                )
            elif message.animation:  # гифки
                bot.send_animation(
                    target_user_id,
                    message.animation.file_id,
                    caption=prefix + (message.caption or ""),
                    reply_to_message_id=original_msg_id
                )
            elif message.voice:
                bot.send_voice(
                    target_user_id,
                    message.voice.file_id,
                    caption="Ответ от поддержки (голосовое)",
                    reply_to_message_id=original_msg_id
                )
            elif message.sticker:
                bot.send_sticker(
                    target_user_id,
                    message.sticker.file_id,
                    reply_to_message_id=original_msg_id
                )
            elif message.document:
                bot.send_document(
                    target_user_id,
                    message.document.file_id,
                    caption=prefix + (message.caption or ""),
                    reply_to_message_id=original_msg_id
                )
            else:
                bot.reply_to(message, "Этот тип сообщения пока не поддерживается для ответа.")
                return

        except Exception as e:
            bot.reply_to(message, f"Ошибка при отправке ответа:\n{str(e)}")

    elif user_id in bans:
        bot.reply_to(message, "Ты забанен и не можешь отправлять сообщения.")

    else:
        # ──────────────── Пересылка сообщения от пользователя админу ────────────────
        try:
            # Пересылаем оригинальное сообщение
            forwarded = bot.forward_message(
                admin,
                message.chat.id,
                message.message_id
            )

            # Запоминаем связь
            forwarded_messages[forwarded.message_id] = (user_id, message.message_id)

            # Отправляем информацию об отправителе (отдельным сообщением)
            user_info = (
                f"Сообщение от пользователя:\n"
                f"ID: {user_id}\n"
                f"@{message.from_user.username or 'нет username'}\n"
                f"{message.from_user.first_name or ''} {message.from_user.last_name or ''}"
            )
            info_msg = bot.send_message(admin, user_info)

            # Запоминаем и это сообщение (чтобы можно было реплайнуть на подпись)
            forwarded_messages[info_msg.message_id] = (user_id, message.message_id)

            # Уведомление пользователю — только один раз
            if user_id not in users_who_wrote:
                bot.reply_to(
                    message,
                    "Сообщение передано администратору. Ожидай ответа :)"
                )
                users_who_wrote.add(user_id)

        except Exception as e:
            bot.reply_to(message, "Не удалось передать сообщение. Попробуй позже.")

def main():
    while True:
        try:
            import logger
            import time

            logger.info("Бот запущен, начинаем polling...")
            bot.polling(none_stop=True, interval=0, timeout=30)
        except Exception as e:
            logger.error(f"Критическая ошибка! Бот упал: {e}", exc_info=True)
            time.sleep(15)  # ждём 15 секунд перед перезапуском
            logger.info("Перезапуск бота через 15 секунд...")

if __name__ == '__main__':
    main()       
            

